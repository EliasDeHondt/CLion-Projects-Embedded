/**
 * @author Elias De Hondt
 * @see https://eliasdh.com
 * @since 09/05/2023
 */

public class Launcher {
    public static void main(String[] args) {
        Main.main(args);
    }
}
