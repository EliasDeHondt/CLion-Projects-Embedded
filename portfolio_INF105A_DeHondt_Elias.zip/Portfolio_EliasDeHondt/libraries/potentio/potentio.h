/**
 * @author Elias De Hondt
 * @see https://eliasdh.com
 * @since 18/04/2023
 */

// Enable
void enablePotentio();

// Read
uint16_t readPotentio();