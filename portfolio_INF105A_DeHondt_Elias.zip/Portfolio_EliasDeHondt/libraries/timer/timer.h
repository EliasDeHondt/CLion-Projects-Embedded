/**
 * @author Elias De Hondt
 * @see https://eliasdh.com
 * @since 09/05/2023
 */

// Enable
void enableTimer2();

// Start
void startTimer2();

// Stop
void stopTimer2();